import { z } from "zod";

/* ============================================================
 *  DIVISION — CREATE
 * ============================================================ */

export const createDivisionSchema = z.object({
  name: z.string().min(1, "Name is required").trim(),
  slug: z.string().optional(), // না দিলে server auto-generate করবে
  thumbnail: z.string().optional(),
  images: z.array(z.string()).optional(),
  description: z.string().optional(),
  districts: z.array(z.string()).optional(),
  location: z
    .object({
      type: z.literal("Point"),
      coordinates: z.tuple([z.number(), z.number()]), // [lng, lat]
    })
    .optional(),
  isActive: z.boolean().optional(),
});

/* ============================================================
 *  DIVISION — UPDATE
 * ============================================================ */

export const updateDivisionSchema = createDivisionSchema.partial();
