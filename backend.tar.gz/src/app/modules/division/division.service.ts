import { deleteImageFromCLoudinary } from "../../config/cloudinary.config";
import { QueryBuilder } from "../../utils/QueryBuilder";
import { divisionSearchableFields } from "./division.constant";
import { IDivision } from "./division.interface";
import { Division } from "./division.model";

/* ============================================================
 *  HELPER — slug generator
 * ============================================================ */
const generateSlug = (name: string): string => {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^\w\u0980-\u09FF\s-]/g, "") // Bengali + English + digits
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
};

/* ============================================================
 *  CREATE
 * ============================================================ */
const createDivision = async (payload: IDivision) => {
  const existingDivision = await Division.findOne({ name: payload.name });
  if (existingDivision) {
    throw new Error("A division with this name already exists.");
  }

  // slug না দিলে auto-generate
  if (!payload.slug) {
    payload.slug = generateSlug(payload.name);
  }

  // slug uniqueness check
  const existingSlug = await Division.findOne({ slug: payload.slug });
  if (existingSlug) {
    throw new Error("A division with this slug already exists.");
  }

  const division = await Division.create(payload);
  return division;
};

/* ============================================================
 *  GET ALL (paginated)
 * ============================================================ */
const getAllDivisions = async (query: Record<string, string>) => {
  const queryBuilder = new QueryBuilder(Division.find(), query);

  const divisionsData = queryBuilder
    .search(divisionSearchableFields)
    .filter()
    .sort()
    .fields()
    .paginate();

  const [data, meta] = await Promise.all([
    divisionsData.build(),
    queryBuilder.getMeta(),
  ]);

  return { data, meta };
};

/* ============================================================
 *  GET SINGLE
 * ============================================================ */
const getSingleDivision = async (slug: string) => {
  const division = await Division.findOne({ slug });
  if (!division) {
    throw new Error("Division not found.");
  }
  return { data: division };
};

/* ============================================================
 *  UPDATE
 * ============================================================ */
const updateDivision = async (id: string, payload: Partial<IDivision>) => {
  const existingDivision = await Division.findById(id);
  if (!existingDivision) {
    throw new Error("Division not found.");
  }

  // ✅ FIX: name থাকলে এবং সত্যিই বদলালে তবেই duplicate check
  if (payload.name && payload.name !== existingDivision.name) {
    const duplicateDivision = await Division.findOne({
      name: payload.name,
      _id: { $ne: id },
    });
    if (duplicateDivision) {
      throw new Error("A division with this name already exists.");
    }

    // name বদলালে slug-ও regenerate (user explicitly slug না দিলে)
    if (!payload.slug) {
      payload.slug = generateSlug(payload.name);
    }
  }

  // ✅ slug explicitly দিলে uniqueness check
  if (payload.slug && payload.slug !== existingDivision.slug) {
    const duplicateSlug = await Division.findOne({
      slug: payload.slug,
      _id: { $ne: id },
    });
    if (duplicateSlug) {
      throw new Error("A division with this slug already exists.");
    }
  }

  const updatedDivision = await Division.findByIdAndUpdate(id, payload, {
    new: true,
    runValidators: true,
  });

  // নতুন thumbnail এলে পুরনোটা Cloudinary থেকে মুছুন
  if (payload.thumbnail && existingDivision.thumbnail) {
    await deleteImageFromCLoudinary(existingDivision.thumbnail);
  }

  return updatedDivision;
};

/* ============================================================
 *  DELETE
 * ============================================================ */
const deleteDivision = async (id: string) => {
  const division = await Division.findById(id);
  if (!division) {
    throw new Error("Division not found.");
  }

  // TODO: referential integrity — Destination/Tour এই division ব্যবহার করছে কি না চেক করুন
  // const hasDestinations = await Destination.exists({ division: id });
  // if (hasDestinations) {
  //   throw new Error("Cannot delete division with existing destinations.");
  // }

  await Division.findByIdAndDelete(id);

  // ✅ Cloudinary থেকে thumbnail মুছুন
  if (division.thumbnail) {
    await deleteImageFromCLoudinary(division.thumbnail);
  }

  return null;
};

export const DivisionService = {
  createDivision,
  getAllDivisions,
  getSingleDivision,
  updateDivision,
  deleteDivision,
};
