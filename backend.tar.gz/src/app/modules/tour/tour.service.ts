import { deleteImageFromCLoudinary } from "../../config/cloudinary.config";
import { QueryBuilder } from "../../utils/QueryBuilder";
import { Destination } from "../destination/destination.model";
import {
  tourSearchableFields,
  tourTypeSearchableFields,
} from "./tour.constant";
import { ITour, ITourType } from "./tour.interface";
import { Tour, TourType } from "./tour.model";

type UpdateTourPayload = Partial<ITour> & {
  deleteImages?: string[];
};

/* ============================================================
 *  HELPER — slug generator
 * ============================================================ */
const generateSlug = (text: string): string => {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\u0980-\u09FF\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
};

/* ============================================================
 *  TOUR — CREATE
 * ============================================================ */
const createTour = async (payload: ITour) => {
  // slug auto-generate
  if (!payload.slug) {
    payload.slug = generateSlug(payload.title);
  }

  const existingTour = await Tour.findOne({
    $or: [{ title: payload.title }, { slug: payload.slug }],
  });
  if (existingTour) {
    throw new Error("A tour with this title or slug already exists.");
  }

  // ✅ referential integrity — destinations exist করে কি না
  if (payload.destinations?.length) {
    const foundDestinations = await Destination.countDocuments({
      _id: { $in: payload.destinations },
    });
    if (foundDestinations !== payload.destinations.length) {
      throw new Error("One or more destinations not found.");
    }
  }

  // ✅ tourType exist করে কি না
  if (payload.tourType) {
    const foundType = await TourType.findById(payload.tourType);
    if (!foundType) {
      throw new Error("Tour type not found.");
    }
  }

  return await Tour.create(payload);
};

/* ============================================================
 *  TOUR — GET ALL
 * ============================================================ */
const getAllTours = async (query: Record<string, string>) => {
  const queryBuilder = new QueryBuilder(Tour.find(), query);

  const tours = queryBuilder
    .search(tourSearchableFields)
    .filter()
    .sort()
    .fields()
    .paginate();

  const [data, meta] = await Promise.all([
    tours
      .build()
      .populate("destinations", "name slug thumbnail")
      .populate("tourType", "name slug icon"),
    queryBuilder.getMeta(),
  ]);

  return { data, meta };
};

/* ============================================================
 *  TOUR — GET SINGLE
 * ============================================================ */
const getSingleTour = async (slug: string) => {
  const tour = await Tour.findOne({ slug })
    .populate("destinations", "name slug thumbnail description")
    .populate("tourType", "name slug icon");

  if (!tour) {
    throw new Error("Tour not found.");
  }

  return tour; // ✅ wrapper বাদ
};

/* ============================================================
 *  TOUR — UPDATE
 * ============================================================ */
const updateTour = async (id: string, payload: UpdateTourPayload) => {
  const existingTour = await Tour.findById(id);
  if (!existingTour) {
    throw new Error("Tour not found.");
  }

  const { deleteImages = [], images: newImages, ...updateData } = payload;

  const finalUpdateData: Partial<ITour> = { ...updateData };

  // ✅ title বদলালে slug regenerate + duplicate check
  if (updateData.title && updateData.title !== existingTour.title) {
    const newSlug = updateData.slug || generateSlug(updateData.title);
    const duplicate = await Tour.findOne({
      _id: { $ne: id },
      $or: [{ title: updateData.title }, { slug: newSlug }],
    });
    if (duplicate) {
      throw new Error("A tour with this title or slug already exists.");
    }
    finalUpdateData.slug = newSlug;
  }

  // ✅ destinations validate
  if (updateData.destinations?.length) {
    const found = await Destination.countDocuments({
      _id: { $in: updateData.destinations },
    });
    if (found !== updateData.destinations.length) {
      throw new Error("One or more destinations not found.");
    }
  }

  // ✅ tourType validate
  if (updateData.tourType) {
    const foundType = await TourType.findById(updateData.tourType);
    if (!foundType) {
      throw new Error("Tour type not found.");
    }
  }

  // ✅ images merge logic
  if (newImages !== undefined || deleteImages.length > 0) {
    const deletedSet = new Set(deleteImages);
    const remaining = (existingTour.images ?? []).filter(
      (url) => !deletedSet.has(url),
    );
    const uploaded = (newImages ?? []).filter((url) => !deletedSet.has(url));
    finalUpdateData.images = [...remaining, ...uploaded];
  }

  const updatedTour = await Tour.findByIdAndUpdate(id, finalUpdateData, {
    new: true,
    runValidators: true,
  });

  // Cloudinary cleanup — update সফল হলে
  if (deleteImages.length > 0) {
    await Promise.all(
      deleteImages.map((url) => deleteImageFromCLoudinary(url)),
    );
  }

  return updatedTour;
};

/* ============================================================
 *  TOUR — DELETE
 * ============================================================ */
const deleteTour = async (id: string) => {
  const tour = await Tour.findById(id);
  if (!tour) {
    throw new Error("Tour not found.");
  }

  // TODO: referential integrity — কোনো booking থাকলে delete আটকান
  // const hasBookings = await Booking.exists({ tour: id });
  // if (hasBookings) throw new Error("Cannot delete tour with existing bookings.");

  await Tour.findByIdAndDelete(id);

  // ✅ Cloudinary cleanup
  if (tour.images?.length) {
    await Promise.all(tour.images.map((url) => deleteImageFromCLoudinary(url)));
  }

  return null;
};

/* ============================================================
 *  TOUR TYPE — CREATE
 * ============================================================ */
const createTourType = async (payload: ITourType) => {
  // slug auto-generate
  if (!payload.slug) {
    payload.slug = generateSlug(payload.name);
  }

  const existingTourType = await TourType.findOne({
    $or: [{ name: payload.name }, { slug: payload.slug }],
  });
  if (existingTourType) {
    throw new Error("A tour type with this name or slug already exists.");
  }

  return await TourType.create(payload);
};

/* ============================================================
 *  TOUR TYPE — GET ALL
 * ============================================================ */
const getAllTourTypes = async (query: Record<string, string>) => {
  const queryBuilder = new QueryBuilder(TourType.find(), query);

  const tourTypes = queryBuilder
    .search(tourTypeSearchableFields)
    .filter()
    .sort()
    .fields()
    .paginate();

  const [data, meta] = await Promise.all([
    tourTypes.build(),
    queryBuilder.getMeta(),
  ]);

  return { data, meta };
};

/* ============================================================
 *  TOUR TYPE — GET SINGLE
 * ============================================================ */
const getSingleTourType = async (id: string) => {
  const tourType = await TourType.findById(id);
  if (!tourType) {
    throw new Error("Tour type not found.");
  }
  return tourType; // ✅ wrapper বাদ
};

/* ============================================================
 *  TOUR TYPE — UPDATE
 * ============================================================ */
const updateTourType = async (id: string, payload: Partial<ITourType>) => {
  const existingTourType = await TourType.findById(id);
  if (!existingTourType) {
    throw new Error("Tour type not found.");
  }

  if (Object.keys(payload).length === 0) {
    return existingTourType;
  }

  // ✅ name বদলালে duplicate check + slug regenerate
  if (payload.name && payload.name !== existingTourType.name) {
    const duplicate = await TourType.findOne({
      _id: { $ne: id },
      name: payload.name,
    });
    if (duplicate) {
      throw new Error("A tour type with this name already exists.");
    }
    if (!payload.slug) {
      payload.slug = generateSlug(payload.name);
    }
  }

  return await TourType.findByIdAndUpdate(id, payload, {
    new: true,
    runValidators: true,
  });
};

/* ============================================================
 *  TOUR TYPE — DELETE
 * ============================================================ */
const deleteTourType = async (id: string) => {
  const existingTourType = await TourType.findById(id);
  if (!existingTourType) {
    throw new Error("Tour type not found.");
  }

  // ✅ referential integrity — কোনো tour এই type ব্যবহার করছে কি না
  const tourCount = await Tour.countDocuments({ tourType: id });
  if (tourCount > 0) {
    throw new Error(
      `Cannot delete tour type. ${tourCount} tour(s) are using it.`,
    );
  }

  return await TourType.findByIdAndDelete(id);
};

export const TourService = {
  createTour,
  createTourType,
  deleteTourType,
  updateTourType,
  getAllTourTypes,
  getSingleTourType,
  getSingleTour,
  getAllTours,
  updateTour,
  deleteTour,
};
