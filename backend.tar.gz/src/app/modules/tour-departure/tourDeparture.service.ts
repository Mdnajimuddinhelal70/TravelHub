import { QueryBuilder } from "../../utils/QueryBuilder";
import { Booking } from "../booking/booking.model";
import { Tour } from "../tour/tour.model";
import {
  ITourDeparture,
  TOUR_DEPARTURE_STATUS,
} from "./tour-departure.interface";
import { TourDeparture } from "./tour-departure.model";

/* ============================================================
 *  CREATE
 * ============================================================ */
const createTourDeparture = async (payload: ITourDeparture) => {
  // ✅ tour exist করে কি না
  const tour = await Tour.findById(payload.tour);
  if (!tour) {
    throw new Error("Tour not found.");
  }

  // ✅ date validation
  if (new Date(payload.endDate) <= new Date(payload.startDate)) {
    throw new Error("End date must be after start date");
  }

  // ✅ একই tour + startDate-এ duplicate check
  const existing = await TourDeparture.findOne({
    tour: payload.tour,
    startDate: payload.startDate,
  });
  if (existing) {
    throw new Error("A departure already exists for this tour on this date.");
  }

  // ✅ availableSeats না দিলে totalSeats-ই হবে
  if (payload.availableSeats === undefined) {
    payload.availableSeats = payload.totalSeats;
  }
  if (payload.bookedSeats === undefined) {
    payload.bookedSeats = 0;
  }

  // ✅ seat arithmetic validation
  if (payload.availableSeats + payload.bookedSeats !== payload.totalSeats) {
    throw new Error("availableSeats + bookedSeats must equal totalSeats");
  }

  return await TourDeparture.create(payload);
};

/* ============================================================
 *  GET ALL (admin)
 * ============================================================ */
const getAllTourDepartures = async (query: Record<string, string>) => {
  const queryBuilder = new QueryBuilder(TourDeparture.find(), query);

  const departures = queryBuilder.filter().sort().fields().paginate();

  const [data, meta] = await Promise.all([
    departures
      .build()
      .populate("tour", "title slug coverImage duration price")
      .populate("guide", "name email"),
    queryBuilder.getMeta(),
  ]);

  return { data, meta };
};

/* ============================================================
 *  GET BY TOUR (public — frontend-এ date list দেখাতে)
 * ============================================================ */
const getDeparturesByTour = async (
  tourId: string,
  query: Record<string, string>,
) => {
  const tour = await Tour.findById(tourId);
  if (!tour) {
    throw new Error("Tour not found.");
  }

  const queryBuilder = new QueryBuilder(
    TourDeparture.find({ tour: tourId }),
    query,
  );

  const departures = queryBuilder.filter().sort().fields().paginate();

  const [data, meta] = await Promise.all([
    departures.build().populate("guide", "name"),
    queryBuilder.getMeta(),
  ]);

  return { data, meta };
};

/* ============================================================
 *  GET SINGLE
 * ============================================================ */
const getSingleTourDeparture = async (id: string) => {
  const departure = await TourDeparture.findById(id)
    .populate("tour", "title slug coverImage duration price")
    .populate("guide", "name email");

  if (!departure) {
    throw new Error("Tour departure not found.");
  }

  return departure;
};

/* ============================================================
 *  UPDATE
 * ============================================================ */
const updateTourDeparture = async (
  id: string,
  payload: Partial<ITourDeparture>,
) => {
  const existing = await TourDeparture.findById(id);
  if (!existing) {
    throw new Error("Tour departure not found.");
  }

  // ✅ date validation (একটা বা দুটোই বদলালে)
  const startDate = payload.startDate ?? existing.startDate;
  const endDate = payload.endDate ?? existing.endDate;
  if (new Date(endDate) <= new Date(startDate)) {
    throw new Error("End date must be after start date");
  }

  // ✅ totalSeats বদলালে availableSeats recalculate
  if (payload.totalSeats !== undefined) {
    if (payload.totalSeats < existing.bookedSeats) {
      throw new Error(
        `Cannot reduce total seats below booked seats (${existing.bookedSeats}).`,
      );
    }
    payload.availableSeats = payload.totalSeats - existing.bookedSeats;
  }

  // ✅ tour বা startDate বদলালে duplicate check
  if (payload.tour || payload.startDate) {
    const duplicate = await TourDeparture.findOne({
      _id: { $ne: id },
      tour: payload.tour ?? existing.tour,
      startDate: payload.startDate ?? existing.startDate,
    });
    if (duplicate) {
      throw new Error("A departure already exists for this tour on this date.");
    }
  }

  // ✅ tour বদলালে exist করে কি না
  if (payload.tour) {
    const tour = await Tour.findById(payload.tour);
    if (!tour) {
      throw new Error("Tour not found.");
    }
  }

  const updated = await TourDeparture.findByIdAndUpdate(id, payload, {
    new: true,
    runValidators: true,
  });

  return updated;
};

/* ============================================================
 *  DELETE
 * ============================================================ */
const deleteTourDeparture = async (id: string) => {
  const departure = await TourDeparture.findById(id);
  if (!departure) {
    throw new Error("Tour departure not found.");
  }

  // ✅ booking থাকলে delete আটকান
  const bookingCount = await Booking.countDocuments({ tourDeparture: id });
  if (bookingCount > 0) {
    throw new Error(
      `Cannot delete departure. ${bookingCount} booking(s) exist.`,
    );
  }

  await TourDeparture.findByIdAndDelete(id);
  return null;
};

/* ============================================================
 *  HELPER — atomic seat decrement (Booking service-এ ব্যবহার হবে)
 * ============================================================ */
const reserveSeats = async (departureId: string, seatCount: number) => {
  const departure = await TourDeparture.findOneAndUpdate(
    {
      _id: departureId,
      status: {
        $in: [TOUR_DEPARTURE_STATUS.OPEN, TOUR_DEPARTURE_STATUS.SCHEDULED],
      },
      availableSeats: { $gte: seatCount },
    },
    {
      $inc: {
        availableSeats: -seatCount,
        bookedSeats: seatCount,
      },
    },
    { new: true },
  );

  if (!departure) {
    throw new Error("Not enough seats available.");
  }

  // ✅ FULL status auto-update (findOneAndUpdate hook চলে না)
  if (departure.availableSeats === 0) {
    await TourDeparture.updateOne(
      { _id: departureId },
      { $set: { status: TOUR_DEPARTURE_STATUS.FULL } },
    );
  }

  return departure;
};

/* ============================================================
 *  HELPER — seat release (booking cancel/expire হলে)
 * ============================================================ */
const releaseSeats = async (departureId: string, seatCount: number) => {
  const departure = await TourDeparture.findByIdAndUpdate(
    departureId,
    {
      $inc: {
        availableSeats: seatCount,
        bookedSeats: -seatCount,
      },
    },
    { new: true },
  );

  if (!departure) {
    throw new Error("Tour departure not found.");
  }

  // ✅ FULL থেকে OPEN-এ ফেরত
  if (
    departure.availableSeats > 0 &&
    departure.status === TOUR_DEPARTURE_STATUS.FULL
  ) {
    await TourDeparture.updateOne(
      { _id: departureId },
      { $set: { status: TOUR_DEPARTURE_STATUS.OPEN } },
    );
  }

  return departure;
};

export const TourDepartureService = {
  createTourDeparture,
  getAllTourDepartures,
  getDeparturesByTour,
  getSingleTourDeparture,
  updateTourDeparture,
  deleteTourDeparture,
  reserveSeats,
  releaseSeats,
};
