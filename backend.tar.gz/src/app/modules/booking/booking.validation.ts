import { z } from "zod";
import { BOOKING_STATUS } from "./booking.interface";

/* ============================================================
 *  REUSABLE SUB-SCHEMAS
 * ============================================================ */

const travelerSchema = z.object({
  name: z.string().min(1, "Traveler name is required").trim(),
  age: z
    .number()
    .int()
    .min(0, "Age cannot be negative")
    .max(120, "Age seems invalid"),
  gender: z.enum(["male", "female", "other"]),
  type: z.enum(["adult", "child"]),
  nidOrPassport: z.string().optional(),
});

const contactInfoSchema = z.object({
  name: z.string().min(1, "Contact name is required").trim(),
  phone: z.string().min(1, "Phone is required").trim(),
  email: z.string().email("Invalid email").trim().toLowerCase(),
  emergencyContact: z.string().optional(),
});

/* ============================================================
 *  BOOKING — CREATE
 * ============================================================ */

export const createBookingZodSchema = z
  .object({
    tourDeparture: z.string().min(1, "Tour departure is required"),

    travelers: z
      .array(travelerSchema)
      .min(1, "At least one traveler is required"),

    adultCount: z.number().int().min(1, "At least one adult is required"),
    childCount: z.number().int().min(0).optional(),

    contactInfo: contactInfoSchema,

    couponCode: z.string().trim().toUpperCase().optional(),
    specialRequests: z.string().optional(),

    // ⚠️ বাদ: bookingNumber, user, tour, payment, guestCount,
    //        priceBreakdown, status, reservationExpiresAt
    //        — এগুলো সব server তৈরি করবে
  })
  .refine(
    (data) => {
      const expected = data.adultCount + (data.childCount ?? 0);
      return data.travelers.length === expected;
    },
    {
      message: "travelers count must equal adultCount + childCount",
      path: ["travelers"],
    },
  )
  .refine(
    (data) => {
      const adultTravelers = data.travelers.filter(
        (t) => t.type === "adult",
      ).length;
      return adultTravelers === data.adultCount;
    },
    {
      message: "adultCount must match travelers with type 'adult'",
      path: ["adultCount"],
    },
  );

/* ============================================================
 *  BOOKING — UPDATE STATUS (admin)
 * ============================================================ */

// Admin সাধারণত এই status গুলোই সেট করবে
const ADMIN_SETTABLE_STATUSES = [
  BOOKING_STATUS.CONFIRMED,
  BOOKING_STATUS.CANCELLED,
  BOOKING_STATUS.COMPLETED,
  BOOKING_STATUS.FAILED,
  BOOKING_STATUS.EXPIRED,
] as const;

export const updateBookingStatusZodSchema = z
  .object({
    status: z.enum(ADMIN_SETTABLE_STATUSES),
    cancellationReason: z.string().optional(),
  })
  .refine(
    (data) =>
      data.status !== BOOKING_STATUS.CANCELLED || !!data.cancellationReason,
    {
      message: "cancellationReason is required when status is CANCELLED",
      path: ["cancellationReason"],
    },
  );

/* ============================================================
 *  BOOKING — USER CANCEL (optional, পরে লাগবে)
 * ============================================================ */

export const cancelBookingZodSchema = z.object({
  cancellationReason: z
    .string()
    .min(5, "Please provide a reason (min 5 characters)"),
});
